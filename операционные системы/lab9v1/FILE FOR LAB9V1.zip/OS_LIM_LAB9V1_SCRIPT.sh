#!/bin/bash

gcc OS_LIM_LAB9V1.c -o OS_LIM_LAB9V1 -lrt -lpthread -Wall -O2
sudo ./OS_LIM_LAB9V1 