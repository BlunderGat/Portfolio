#!/bin/bash
gcc -c OS_LIM_LAB1.c
gcc -o OS_LIM_LAB1 OS_LIM_LAB1.o -lpthread
./OS_LIM_LAB1